/* shared.js — Loaded on every page
   1. Auto-highlights current page in the site-header nav
   2. Footer "loaded" animation
   3. Google Analytics (gtag) — centralized here so other pages don't need inline gtag scripts
*/

(function () {
  'use strict';

  /* ── 1. Auto-highlight active nav link ── */
  (function setActiveNav() {
    try {
      var path = window.location.pathname;
      var page = path.substring(path.lastIndexOf('/') + 1) || 'index.html';
      var links = document.querySelectorAll('.site-header nav a');
      for (var i = 0; i < links.length; i++) {
        var href = links[i].getAttribute('href') || '';
        if (href === page) {
          links[i].classList.add('active');
        } else {
          links[i].classList.remove('active');
        }
      }
    } catch (e) { /* ignore */ }
  })();

  /* ── 2. Footer loaded animation ── */
  window.addEventListener('load', function () {
    try {
      var footer = document.querySelector('.site-footer');
      if (footer) footer.classList.add('loaded');
    } catch (e) { /* ignore */ }
  });

})();
