/* shared.js — Loaded on every page
   1. Auto-highlights current page in the site-header nav
   2. Footer "loaded" animation
   3. Hide site-header on scroll down, show on scroll up (mobile/small screens)
*/

(function () {
  'use strict';

  /* ── 1. Auto-highlight active nav link ── */
  (function setActiveNav() {
    try {
      var path = window.location.pathname;
      var page = path.substring(path.lastIndexOf('/') + 1) || 'index.html';
      var links = document.querySelectorAll('.site-header nav a');
      for (var i = 0; i < links.length; i++) {
        var href = links[i].getAttribute('href') || '';
        if (href === page) {
          links[i].classList.add('active');
        } else {
          links[i].classList.remove('active');
        }
      }
    } catch (e) { /* ignore */ }
  })();

  /* ── 2. Footer loaded animation ── */
  window.addEventListener('load', function () {
    try {
      var footer = document.querySelector('.site-footer');
      if (footer) footer.classList.add('loaded');
    } catch (e) { /* ignore */ }
  });

  /* ── 3. Hide site-header on scroll down, show on scroll up (mobile ≤768px) ── */
  (function headerScrollHide() {
    var header = document.querySelector('.site-header');
    if (!header) return;

    var lastScrollY = 0;
    var ticking = false;
    var HIDE_THRESHOLD = 80; // pixels to scroll before hiding starts

    function onScroll() {
      if (!ticking) {
        window.requestAnimationFrame(function () {
          var currentScrollY = window.scrollY || window.pageYOffset;
          var isSmallScreen = window.innerWidth <= 768;

          if (isSmallScreen && currentScrollY > HIDE_THRESHOLD) {
            if (currentScrollY > lastScrollY) {
              // Scrolling down — hide header
              header.classList.add('header-hidden');
            } else {
              // Scrolling up — show header
              header.classList.remove('header-hidden');
            }
          } else {
            // At top or on desktop — always show header
            header.classList.remove('header-hidden');
          }

          lastScrollY = currentScrollY;
          ticking = false;
        });
        ticking = true;
      }
    }

    window.addEventListener('scroll', onScroll, { passive: true });
  })();

})();
